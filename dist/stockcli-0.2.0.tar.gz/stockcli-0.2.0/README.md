# stockcli

## _This is a CLI tool to retrieve data from [finance.yahoo.com](https://finance.yahoo.com/)._

#### Available commands

![cli](https://i.ibb.co/j43zt5L/cli.png)